from setuptools import setup, find_packages

setup(
    name="dataflow",
    version="0.3.0",
    description="A composable data pipeline library for transforming tabular records",
    author="Anirudh Sharma",
    packages=find_packages(exclude=["tests*"]),
    python_requires=">=3.9",
    install_requires=[],
    extras_require={
        "dev": ["pytest>=8.0", "pytest-cov>=5.0"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
