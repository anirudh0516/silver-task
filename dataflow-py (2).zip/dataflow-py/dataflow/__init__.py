"""
dataflow — a composable data pipeline library for tabular records.

Records are plain Python dicts with string keys. All transforms are
pure functions that accept and return lists of dicts, making them easy
to compose, test, and debug.

Example usage::

    from dataflow import Pipeline
    from dataflow.readers import read_csv

    results = (
        Pipeline(read_csv("sales.csv"))
        .filter(lambda r: float(r["amount"]) > 100)
        .select("region", "product", "amount")
        .sort("amount", reverse=True)
        .limit(10)
        .collect()
    )
"""

from dataflow.pipeline import Pipeline
from dataflow.transforms import (
    filter_records,
    map_records,
    select_fields,
    rename_fields,
    add_field,
    group_by,
    aggregate,
    sort_records,
    limit,
    offset,
)

__all__ = [
    "Pipeline",
    "filter_records",
    "map_records",
    "select_fields",
    "rename_fields",
    "add_field",
    "group_by",
    "aggregate",
    "sort_records",
    "limit",
    "offset",
]
