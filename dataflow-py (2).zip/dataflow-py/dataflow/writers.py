"""
Writers for serialising record lists to various output formats.
"""

import csv
import io
import json
from typing import Any, Dict, List, Optional, TextIO


def write_csv(
    records: List[Dict],
    path: str,
    *,
    fields: Optional[List[str]] = None,
    delimiter: str = ",",
    encoding: str = "utf-8",
    lineterminator: str = "\n",
) -> None:
    """
    Write records to a CSV file.

    Args:
        records: Records to write.
        path: Destination file path.
        fields: Column order. If None, uses all keys from the first record.
        delimiter: Field delimiter.
        encoding: Output encoding.
        lineterminator: Line terminator character(s).
    """
    if not records:
        with open(path, "w", encoding=encoding, newline="") as f:
            f.write("")
        return

    if fields is None:
        fields = list(records[0].keys())

    with open(path, "w", encoding=encoding, newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=fields,
            delimiter=delimiter,
            lineterminator=lineterminator,
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(records)


def to_csv_string(
    records: List[Dict],
    *,
    fields: Optional[List[str]] = None,
    delimiter: str = ",",
) -> str:
    """Serialize records to a CSV string (without writing to disk)."""
    if not records:
        return ""
    if fields is None:
        fields = list(records[0].keys())
    buf = io.StringIO()
    writer = csv.DictWriter(
        buf,
        fieldnames=fields,
        delimiter=delimiter,
        extrasaction="ignore",
        lineterminator="\n",
    )
    writer.writeheader()
    writer.writerows(records)
    return buf.getvalue()


def write_json(
    records: List[Dict],
    path: str,
    *,
    encoding: str = "utf-8",
    indent: int = 2,
    root_key: Optional[str] = None,
) -> None:
    """
    Write records to a JSON file as an array of objects.

    Args:
        records: Records to write.
        path: Destination file path.
        encoding: Output encoding.
        indent: JSON indentation level.
        root_key: If provided, wrap the array in {root_key: [...]}
    """
    data: Any = records if root_key is None else {root_key: records}
    with open(path, "w", encoding=encoding) as f:
        json.dump(data, f, indent=indent, default=str)


def to_json_string(
    records: List[Dict],
    *,
    indent: int = 2,
    root_key: Optional[str] = None,
) -> str:
    """Serialize records to a JSON string (without writing to disk)."""
    data: Any = records if root_key is None else {root_key: records}
    return json.dumps(data, indent=indent, default=str)
