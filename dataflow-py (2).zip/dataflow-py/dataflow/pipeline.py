"""
Pipeline — fluent interface for composing data transforms.

Transforms are accumulated and applied lazily when .collect() is called.
Each method returns self, enabling method chaining.

Example::

    result = (
        Pipeline(records)
        .filter(lambda r: r["active"])
        .rename(user_id="id", full_name="name")
        .add("score", lambda r: int(r["clicks"]) * 10)
        .sort("score", reverse=True)
        .limit(5)
        .collect()
    )
"""

from typing import Any, Callable, Dict, List, Optional

from dataflow import transforms as _t


class Pipeline:
    """
    A composable, lazily-evaluated data pipeline.

    Accepts a list of record dicts on construction; each chained method
    registers a transform step. Steps are applied in order when .collect()
    or a terminal method (.count(), .first()) is called.
    """

    def __init__(self, records: List[Dict]) -> None:
        self._source: List[Dict] = records
        self._steps: List[Callable[[List[Dict]], List[Dict]]] = []

    # ------------------------------------------------------------------
    # Transform steps (return self for chaining)
    # ------------------------------------------------------------------

    def filter(self, predicate: Callable[[Dict], bool]) -> "Pipeline":
        """Keep only records for which predicate returns True."""
        self._steps.append(lambda r, p=predicate: _t.filter_records(r, p))
        return self

    def map(self, fn: Callable[[Dict], Dict]) -> "Pipeline":
        """Apply fn to every record."""
        self._steps.append(lambda r, f=fn: _t.map_records(r, f))
        return self

    def select(self, *fields: str) -> "Pipeline":
        """Keep only the named fields in each record."""
        field_list = list(fields)
        self._steps.append(lambda r: _t.select_fields(r, field_list))
        return self

    def rename(self, **mapping: str) -> "Pipeline":
        """Rename fields; keyword args are old_name=new_name pairs."""
        self._steps.append(lambda r, m=dict(mapping): _t.rename_fields(r, m))
        return self

    def add(self, name: str, fn: Callable[[Dict], Any]) -> "Pipeline":
        """Compute a new field from each record."""
        self._steps.append(lambda r, n=name, f=fn: _t.add_field(r, n, f))
        return self

    def sort(self, key: str, reverse: bool = False) -> "Pipeline":
        """Sort records by the named field (numeric or lexicographic)."""
        self._steps.append(lambda r, k=key, rev=reverse: _t.sort_records(r, k, rev))
        return self

    def limit(self, n: int) -> "Pipeline":
        """Keep at most n records."""
        self._steps.append(lambda r, n=n: _t.limit(r, n))
        return self

    def offset(self, n: int) -> "Pipeline":
        """Skip the first n records."""
        self._steps.append(lambda r, n=n: _t.offset(r, n))
        return self

    # ------------------------------------------------------------------
    # Terminal methods
    # ------------------------------------------------------------------

    def collect(self) -> List[Dict]:
        """Execute the pipeline and return all resulting records."""
        result = list(self._source)
        for step in self._steps:
            result = step(result)
        return result

    def count(self) -> int:
        """Return the number of records after all transforms."""
        return len(self.collect())

    def first(self) -> Optional[Dict]:
        """Return the first record, or None if the result is empty."""
        records = self.collect()
        return records[0] if records else None

    def group_and_aggregate(
        self,
        keys: List[str],
        field: str,
        operation: str,
    ) -> List[Dict]:
        """
        Convenience method: collect records, group by keys, then aggregate.

        Args:
            keys: Fields to group by.
            field: Field to aggregate.
            operation: 'count', 'sum', 'avg', 'min', or 'max'.

        Returns:
            List of aggregation result records.
        """
        records = self.collect()
        groups = _t.group_by(records, keys)
        return _t.aggregate(groups, field, operation)

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return self.count()

    def __repr__(self) -> str:
        return (
            f"Pipeline(source_len={len(self._source)}, steps={len(self._steps)})"
        )
