"""Utility helpers for type coercion, validation, and schema inference."""

from typing import Any, Dict, List, Optional


def try_cast_numeric(value: Any) -> Any:
    """
    Attempt to cast a value to int or float. Returns the original value
    if casting fails. This is used when reading CSV data where all fields
    arrive as strings.
    """
    if not isinstance(value, str):
        return value
    stripped = value.strip()
    if not stripped:
        return value
    try:
        as_int = int(stripped)
        return as_int
    except ValueError:
        pass
    try:
        as_float = float(stripped)
        return as_float
    except ValueError:
        pass
    return value


def cast_record(record: Dict[str, Any], auto_cast: bool = True) -> Dict[str, Any]:
    """
    Apply numeric auto-casting to all fields in a record if auto_cast is True.
    Fields that look like integers become int; fields that look like floats
    become float; everything else remains a string.
    """
    if not auto_cast:
        return record
    return {k: try_cast_numeric(v) for k, v in record.items()}


def infer_schema(records: List[Dict]) -> Dict[str, str]:
    """
    Infer a simple type schema from a list of records. Returns a dict
    mapping field names to one of: 'int', 'float', 'str', 'mixed'.
    """
    if not records:
        return {}

    schema: Dict[str, set] = {}
    for record in records:
        for key, value in record.items():
            if key not in schema:
                schema[key] = set()
            if isinstance(value, int):
                schema[key].add("int")
            elif isinstance(value, float):
                schema[key].add("float")
            else:
                schema[key].add("str")

    result = {}
    for key, types in schema.items():
        if len(types) == 1:
            result[key] = next(iter(types))
        elif types == {"int", "float"}:
            result[key] = "float"
        else:
            result[key] = "mixed"
    return result


def validate_required(records: List[Dict], fields: List[str]) -> List[str]:
    """
    Check that all records contain the required fields.
    Returns a list of error messages (empty if validation passes).
    """
    errors = []
    for i, record in enumerate(records):
        for field in fields:
            if field not in record:
                errors.append(
                    f"Record {i} is missing required field {field!r}"
                )
    return errors


def flatten_record(record: Dict[str, Any], prefix: str = "", sep: str = ".") -> Dict[str, Any]:
    """
    Flatten a nested dict into a single-level dict with dotted keys.
    Nested dicts are recursively flattened; other values are left as-is.
    """
    items: Dict[str, Any] = {}
    for key, value in record.items():
        new_key = f"{prefix}{sep}{key}" if prefix else key
        if isinstance(value, dict):
            items.update(flatten_record(value, new_key, sep))
        else:
            items[new_key] = value
    return items


def safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    """
    Convert value to float, returning default if conversion fails.
    Useful when working with mixed-type fields.
    """
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default
