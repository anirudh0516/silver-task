"""
Readers for loading tabular data from various sources.

All readers return a list of dicts with string keys. Numeric auto-casting
is applied by default so that downstream transforms can do arithmetic
without explicit type conversion.
"""

import csv
import io
import json
from typing import Any, Dict, List, Optional

from dataflow.utils import cast_record


def read_csv(
    path: str,
    *,
    delimiter: str = ",",
    encoding: str = "utf-8",
    auto_cast: bool = True,
    skip_empty: bool = True,
) -> List[Dict[str, Any]]:
    """
    Read a CSV file and return a list of dicts.

    Args:
        path: Path to the CSV file.
        delimiter: Field delimiter (default comma).
        encoding: File encoding.
        auto_cast: When True, numeric strings are coerced to int/float.
        skip_empty: When True, rows where all values are empty are skipped.

    Returns:
        List of record dicts.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the CSV has no header row.
    """
    with open(path, encoding=encoding, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        if reader.fieldnames is None:
            raise ValueError(f"CSV file {path!r} appears to have no header row")
        records = []
        for row in reader:
            if skip_empty and all(v == "" for v in row.values()):
                continue
            records.append(cast_record(dict(row), auto_cast=auto_cast))
    return records


def read_csv_string(
    text: str,
    *,
    delimiter: str = ",",
    auto_cast: bool = True,
    skip_empty: bool = True,
) -> List[Dict[str, Any]]:
    """
    Parse CSV from a string and return a list of dicts.
    Useful for testing without touching the filesystem.
    """
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if reader.fieldnames is None:
        raise ValueError("CSV string appears to have no header row")
    records = []
    for row in reader:
        if skip_empty and all(v == "" for v in row.values()):
            continue
        records.append(cast_record(dict(row), auto_cast=auto_cast))
    return records


def read_json(
    path: str,
    *,
    encoding: str = "utf-8",
    root_key: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Read a JSON file and return a list of dicts.

    The JSON may be:
    - A top-level array of objects.
    - A top-level object with a key that holds the array (use root_key).

    Args:
        path: Path to the JSON file.
        encoding: File encoding.
        root_key: If the array is nested under a key, specify it here.

    Returns:
        List of record dicts.

    Raises:
        ValueError: If the loaded data is not a list (or the root_key is missing).
    """
    with open(path, encoding=encoding) as f:
        data = json.load(f)

    if root_key is not None:
        if not isinstance(data, dict) or root_key not in data:
            raise ValueError(
                f"Expected JSON object with key {root_key!r}, got {type(data).__name__}"
            )
        data = data[root_key]

    if not isinstance(data, list):
        raise ValueError(
            f"Expected a JSON array, got {type(data).__name__}"
        )

    for i, item in enumerate(data):
        if not isinstance(item, dict):
            raise ValueError(
                f"Expected each JSON array element to be an object, "
                f"but element {i} is {type(item).__name__}"
            )

    return data


def read_json_string(
    text: str,
    *,
    root_key: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Parse JSON from a string and return a list of dicts."""
    data = json.loads(text)
    if root_key is not None:
        data = data[root_key]
    if not isinstance(data, list):
        raise ValueError(f"Expected a JSON array, got {type(data).__name__}")
    return data
