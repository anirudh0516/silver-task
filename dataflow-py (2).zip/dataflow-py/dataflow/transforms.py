"""
Core transform functions for manipulating lists of record dicts.

All functions are pure and stateless: they accept a list of records and
return a new list (never mutating their input). This makes them easy to
compose, test in isolation, and reason about.
"""

from typing import Any, Callable, Dict, List, Optional, Union


# ---------------------------------------------------------------------------
# Row-level transforms
# ---------------------------------------------------------------------------


def filter_records(
    records: List[Dict],
    predicate: Callable[[Dict], bool],
) -> List[Dict]:
    """Keep only records for which predicate returns True."""
    result = []
    for r in records:
        try:
            if predicate(r):
                result.append(r)
        except (KeyError, TypeError, ValueError):
            pass
    return result


def map_records(
    records: List[Dict],
    fn: Callable[[Dict], Dict],
) -> List[Dict]:
    """Apply fn to each record and return the transformed list."""
    return [fn(r) for r in records]


def select_fields(records: List[Dict], fields: List[str]) -> List[Dict]:
    """Return records containing only the specified fields."""
    return [{k: r[k] for k in fields if k in r} for r in records]


def rename_fields(records: List[Dict], mapping: Dict[str, str]) -> List[Dict]:
    """
    Rename fields according to mapping {old_name: new_name}.
    Fields not in the mapping are kept unchanged.
    """
    result = []
    for record in records:
        new_record = {mapping.get(k, k): v for k, v in record.items()}
        result.append(new_record)
    return result


def add_field(
    records: List[Dict],
    name: str,
    fn: Callable[[Dict], Any],
) -> List[Dict]:
    """Add a computed field to each record without mutating the originals."""
    result = []
    for record in records:
        new_record = dict(record)
        new_record[name] = fn(record)
        result.append(new_record)
    return result


# ---------------------------------------------------------------------------
# Sorting and slicing
# ---------------------------------------------------------------------------


def sort_records(
    records: List[Dict],
    key: str,
    reverse: bool = False,
) -> List[Dict]:
    """
    Sort records by the named field.

    Numeric fields are sorted numerically; string fields lexicographically.
    Records missing the sort field are placed at the end.
    """
    def _sort_key(r: Dict) -> tuple:
        val = r.get(key)
        if val is None:
            return (2, 0, "")
        if isinstance(val, (int, float)):
            return (0, val, "")
        try:
            return (0, float(val), "")
        except (TypeError, ValueError):
            return (1, 0, str(val))

    return sorted(records, key=_sort_key, reverse=reverse)


def limit(records: List[Dict], n: int) -> List[Dict]:
    """Return the first n records."""
    if n < 0:
        raise ValueError(f"limit must be non-negative, got {n}")
    return records[:n]


def offset(records: List[Dict], n: int) -> List[Dict]:
    """Skip the first n records and return the rest."""
    if n < 0:
        raise ValueError(f"offset must be non-negative, got {n}")
    return records[n:]


# ---------------------------------------------------------------------------
# Grouping and aggregation
# ---------------------------------------------------------------------------


def group_by(records: List[Dict], keys: List[str]) -> Dict[str, List[Dict]]:
    """
    Group records by one or more field keys.

    Returns a dict mapping a group identifier to the list of records
    that share that combination of key values.

    Args:
        records: Input records.
        keys: One or more field names to group by.

    Returns:
        Dict of {group_key: [records]}.
    """
    if not keys:
        raise ValueError("group_by requires at least one key")

    groups: Dict[str, List[Dict]] = {}
    for record in records:
        # Build a composite string key from the values of each grouping field.
        # The pipe character "|" is used as a separator between field values.
        group_key = "|".join(str(record.get(k, "")) for k in keys)
        if group_key not in groups:
            groups[group_key] = []
        groups[group_key].append(record)
    return groups


def aggregate(
    groups: Dict,
    field: str,
    operation: str,
) -> List[Dict]:
    """
    Aggregate grouped records, computing a single value per group.

    Args:
        groups: Output from group_by() — a dict of group_key -> records.
        field: The field to aggregate over.
        operation: One of 'count', 'sum', 'avg', 'min', 'max'.

    Returns:
        List of dicts, each containing '_group_key' and the operation result.

    Raises:
        ValueError: For an unknown operation or if numeric conversion fails.
    """
    valid_ops = {"count", "sum", "avg", "min", "max"}
    if operation not in valid_ops:
        raise ValueError(
            f"Unknown operation {operation!r}. Valid options: {sorted(valid_ops)}"
        )

    result = []
    for group_key, records in groups.items():
        numeric_values: List[float] = []
        for r in records:
            val = r.get(field)
            if val is None:
                continue
            try:
                numeric_values.append(float(val))
            except (TypeError, ValueError):
                pass

        if operation == "count":
            agg_value: Any = len(records)
        elif operation == "sum":
            agg_value = sum(numeric_values) if numeric_values else 0.0
        elif operation == "avg":
            agg_value = (
                sum(numeric_values) / len(numeric_values)
                if numeric_values
                else None
            )
        elif operation == "min":
            agg_value = min(numeric_values) if numeric_values else None
        elif operation == "max":
            agg_value = max(numeric_values) if numeric_values else None

        result.append({"_group_key": group_key, operation: agg_value})

    return result


def pivot(
    records: List[Dict],
    index: str,
    column: str,
    value: str,
    agg: str = "sum",
) -> List[Dict]:
    """
    Pivot records: unique values of `column` become new fields, with cells
    holding the aggregated `value` for each (`index`, `column`) pair.

    Args:
        records: Input records.
        index: Field whose distinct values become row identifiers.
        column: Field whose distinct values become new column names.
        value: Numeric field to aggregate into cells.
        agg: Aggregation to apply ('sum', 'count', 'avg', 'min', 'max').

    Returns:
        List of dicts, one per distinct index value.
    """
    from collections import defaultdict

    cells: Dict[Any, Dict[str, list]] = defaultdict(lambda: defaultdict(list))
    for r in records:
        idx_val = r.get(index)
        col_val = r.get(column)
        val = r.get(value)
        if val is not None:
            cells[idx_val][col_val].append(val)

    col_names = sorted({r.get(column) for r in records if r.get(column) is not None})

    def _agg(vals: list) -> Any:
        if not vals:
            return None
        floats = [float(v) for v in vals]
        if agg == "sum":
            return sum(floats)
        if agg == "count":
            return len(floats)
        if agg == "avg":
            return sum(floats) / len(floats)
        if agg == "min":
            return min(floats)
        if agg == "max":
            return max(floats)
        raise ValueError(f"Unknown aggregation: {agg!r}")

    result = []
    for idx_val in sorted(cells):
        row = {index: idx_val}
        for col in col_names:
            row[str(col)] = _agg(cells[idx_val][col])
        result.append(row)
    return result
