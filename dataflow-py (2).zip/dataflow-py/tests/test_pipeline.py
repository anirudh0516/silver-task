"""Tests for the Pipeline fluent interface."""

import pytest
from dataflow import Pipeline


SAMPLE = [
    {"name": "alice", "dept": "eng", "salary": 90000, "active": True},
    {"name": "bob", "dept": "eng", "salary": 75000, "active": True},
    {"name": "carol", "dept": "hr", "salary": 65000, "active": False},
    {"name": "dave", "dept": "hr", "salary": 70000, "active": True},
    {"name": "eve", "dept": "eng", "salary": 110000, "active": True},
]


def test_pipeline_collect_unchanged():
    result = Pipeline(list(SAMPLE)).collect()
    assert result == SAMPLE


def test_pipeline_filter():
    result = Pipeline(list(SAMPLE)).filter(lambda r: r["active"]).collect()
    assert len(result) == 4
    assert all(r["active"] for r in result)


def test_pipeline_select():
    result = Pipeline(list(SAMPLE)).select("name", "dept").collect()
    for r in result:
        assert set(r.keys()) == {"name", "dept"}


def test_pipeline_rename():
    result = Pipeline(list(SAMPLE)).rename(name="employee").collect()
    assert all("employee" in r for r in result)
    assert all("name" not in r for r in result)


def test_pipeline_add():
    result = (
        Pipeline(list(SAMPLE))
        .add("bonus", lambda r: int(r["salary"]) * 0.1)
        .collect()
    )
    assert result[0]["bonus"] == pytest.approx(9000.0)


def test_pipeline_sort_ascending():
    result = Pipeline(list(SAMPLE)).sort("salary").collect()
    salaries = [r["salary"] for r in result]
    assert salaries == sorted(salaries)


def test_pipeline_sort_descending():
    result = Pipeline(list(SAMPLE)).sort("salary", reverse=True).collect()
    salaries = [r["salary"] for r in result]
    assert salaries == sorted(salaries, reverse=True)


def test_pipeline_limit():
    result = Pipeline(list(SAMPLE)).limit(2).collect()
    assert len(result) == 2


def test_pipeline_offset():
    result = Pipeline(list(SAMPLE)).offset(3).collect()
    assert len(result) == 2


def test_pipeline_chained():
    result = (
        Pipeline(list(SAMPLE))
        .filter(lambda r: r["active"])
        .sort("salary", reverse=True)
        .limit(2)
        .select("name", "salary")
        .collect()
    )
    assert len(result) == 2
    assert result[0]["salary"] >= result[1]["salary"]
    assert set(result[0].keys()) == {"name", "salary"}


def test_pipeline_count():
    n = Pipeline(list(SAMPLE)).filter(lambda r: r["dept"] == "eng").count()
    assert n == 3


def test_pipeline_first():
    record = Pipeline(list(SAMPLE)).sort("salary").first()
    assert record is not None
    assert record["name"] == "carol"


def test_pipeline_first_empty():
    result = Pipeline([]).filter(lambda r: True).first()
    assert result is None


def test_pipeline_group_and_aggregate_sum():
    result = Pipeline(list(SAMPLE)).group_and_aggregate(["dept"], "salary", "sum")
    sums = {r["_group_key"]: r["sum"] for r in result}
    assert sums["eng"] == pytest.approx(275000.0)
    assert sums["hr"] == pytest.approx(135000.0)


def test_pipeline_group_and_aggregate_count():
    result = Pipeline(list(SAMPLE)).group_and_aggregate(["dept"], "salary", "count")
    counts = {r["_group_key"]: r["count"] for r in result}
    assert counts["eng"] == 3
    assert counts["hr"] == 2


def test_pipeline_does_not_mutate_source():
    source = [{"a": 1}, {"a": 2}]
    Pipeline(source).filter(lambda r: r["a"] > 1).collect()
    assert len(source) == 2


def test_pipeline_repr():
    p = Pipeline(SAMPLE)
    assert "Pipeline" in repr(p)
