"""Tests for CSV and JSON readers."""

import json
import os
import tempfile

import pytest
from dataflow.readers import read_csv, read_csv_string, read_json, read_json_string


# ---------------------------------------------------------------------------
# CSV string reader
# ---------------------------------------------------------------------------

CSV_TEXT = """\
name,age,score
alice,30,95.5
bob,25,87.0
carol,35,
"""


def test_csv_string_basic():
    records = read_csv_string(CSV_TEXT)
    assert len(records) == 3
    assert records[0]["name"] == "alice"


def test_csv_string_auto_cast_int():
    records = read_csv_string(CSV_TEXT)
    assert records[0]["age"] == 30
    assert isinstance(records[0]["age"], int)


def test_csv_string_auto_cast_float():
    records = read_csv_string(CSV_TEXT)
    assert records[0]["score"] == pytest.approx(95.5)


def test_csv_string_no_auto_cast():
    records = read_csv_string(CSV_TEXT, auto_cast=False)
    assert records[0]["age"] == "30"
    assert isinstance(records[0]["age"], str)


def test_csv_string_empty_string_stays_string():
    records = read_csv_string(CSV_TEXT)
    assert records[2]["score"] == ""


def test_csv_string_skip_empty_rows():
    text = "a,b\n1,2\n\n3,4\n"
    records = read_csv_string(text)
    assert len(records) == 2


def test_csv_string_custom_delimiter():
    text = "a|b\n1|2\n3|4"
    records = read_csv_string(text, delimiter="|")
    assert records[0] == {"a": 1, "b": 2}


# ---------------------------------------------------------------------------
# CSV file reader
# ---------------------------------------------------------------------------


def test_read_csv_file():
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, encoding="utf-8"
    ) as f:
        f.write("x,y\n10,20\n30,40\n")
        path = f.name
    try:
        records = read_csv(path)
        assert records == [{"x": 10, "y": 20}, {"x": 30, "y": 40}]
    finally:
        os.unlink(path)


def test_read_csv_file_not_found():
    with pytest.raises(FileNotFoundError):
        read_csv("/nonexistent/path/file.csv")


# ---------------------------------------------------------------------------
# JSON string reader
# ---------------------------------------------------------------------------


def test_json_string_array():
    text = '[{"a": 1}, {"a": 2}]'
    records = read_json_string(text)
    assert records == [{"a": 1}, {"a": 2}]


def test_json_string_root_key():
    text = '{"items": [{"a": 1}]}'
    records = read_json_string(text, root_key="items")
    assert records == [{"a": 1}]


def test_json_string_not_array_raises():
    with pytest.raises(ValueError):
        read_json_string('{"a": 1}')


# ---------------------------------------------------------------------------
# JSON file reader
# ---------------------------------------------------------------------------


def test_read_json_file():
    data = [{"name": "alice", "score": 95}]
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        path = f.name
    try:
        records = read_json(path)
        assert records == data
    finally:
        os.unlink(path)


def test_read_json_file_root_key():
    data = {"results": [{"id": 1}]}
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        path = f.name
    try:
        records = read_json(path, root_key="results")
        assert records == [{"id": 1}]
    finally:
        os.unlink(path)


def test_read_json_missing_root_key_raises():
    data = {"other": []}
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        path = f.name
    try:
        with pytest.raises(ValueError, match="results"):
            read_json(path, root_key="results")
    finally:
        os.unlink(path)
