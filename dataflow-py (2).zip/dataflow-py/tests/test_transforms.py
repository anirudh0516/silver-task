"""Tests for dataflow.transforms — all functions except group_by/aggregate edge cases."""

import pytest
from dataflow.transforms import (
    filter_records,
    map_records,
    select_fields,
    rename_fields,
    add_field,
    sort_records,
    limit,
    offset,
    group_by,
    aggregate,
)


# ---------------------------------------------------------------------------
# filter_records
# ---------------------------------------------------------------------------


def test_filter_basic():
    records = [{"x": 1}, {"x": 2}, {"x": 3}]
    result = filter_records(records, lambda r: r["x"] > 1)
    assert result == [{"x": 2}, {"x": 3}]


def test_filter_keeps_all():
    records = [{"a": 1}, {"a": 2}]
    assert filter_records(records, lambda r: True) == records


def test_filter_removes_all():
    records = [{"a": 1}, {"a": 2}]
    assert filter_records(records, lambda r: False) == []


def test_filter_empty_input():
    assert filter_records([], lambda r: True) == []


def test_filter_swallows_missing_key():
    records = [{"a": 1}, {"b": 2}, {"a": 3}]
    result = filter_records(records, lambda r: r["a"] > 1)
    assert result == [{"a": 3}]


# ---------------------------------------------------------------------------
# map_records
# ---------------------------------------------------------------------------


def test_map_basic():
    records = [{"x": 1}, {"x": 2}]
    result = map_records(records, lambda r: {**r, "y": r["x"] * 2})
    assert result == [{"x": 1, "y": 2}, {"x": 2, "y": 4}]


def test_map_empty():
    assert map_records([], lambda r: r) == []


# ---------------------------------------------------------------------------
# select_fields
# ---------------------------------------------------------------------------


def test_select_keeps_named_fields():
    records = [{"a": 1, "b": 2, "c": 3}]
    assert select_fields(records, ["a", "c"]) == [{"a": 1, "c": 3}]


def test_select_missing_field_is_skipped():
    records = [{"a": 1}]
    assert select_fields(records, ["a", "b"]) == [{"a": 1}]


def test_select_empty_fields():
    records = [{"a": 1, "b": 2}]
    assert select_fields(records, []) == [{}]


# ---------------------------------------------------------------------------
# rename_fields
# ---------------------------------------------------------------------------


def test_rename_basic():
    records = [{"old_name": 1, "keep": 2}]
    result = rename_fields(records, {"old_name": "new_name"})
    assert result == [{"new_name": 1, "keep": 2}]


def test_rename_no_match_leaves_unchanged():
    records = [{"a": 1}]
    result = rename_fields(records, {"b": "c"})
    assert result == [{"a": 1}]


# ---------------------------------------------------------------------------
# add_field
# ---------------------------------------------------------------------------


def test_add_field_computed():
    records = [{"price": 10, "qty": 3}]
    result = add_field(records, "total", lambda r: r["price"] * r["qty"])
    assert result == [{"price": 10, "qty": 3, "total": 30}]


def test_add_field_does_not_mutate():
    original = [{"a": 1}]
    _ = add_field(original, "b", lambda r: 2)
    assert "b" not in original[0]


# ---------------------------------------------------------------------------
# sort_records
# ---------------------------------------------------------------------------


def test_sort_numeric_ascending():
    records = [{"v": 30}, {"v": 10}, {"v": 20}]
    result = sort_records(records, "v")
    assert [r["v"] for r in result] == [10, 20, 30]


def test_sort_numeric_descending():
    records = [{"v": 1}, {"v": 3}, {"v": 2}]
    result = sort_records(records, "v", reverse=True)
    assert [r["v"] for r in result] == [3, 2, 1]


def test_sort_string_lexicographic():
    records = [{"name": "charlie"}, {"name": "alice"}, {"name": "bob"}]
    result = sort_records(records, "name")
    assert [r["name"] for r in result] == ["alice", "bob", "charlie"]


def test_sort_numeric_strings():
    records = [{"n": "10"}, {"n": "9"}, {"n": "100"}]
    result = sort_records(records, "n")
    assert [r["n"] for r in result] == ["9", "10", "100"]


def test_sort_missing_field_at_end():
    records = [{"v": 2}, {}, {"v": 1}]
    result = sort_records(records, "v")
    assert result[0]["v"] == 1
    assert result[1]["v"] == 2
    assert "v" not in result[2]


# ---------------------------------------------------------------------------
# limit / offset
# ---------------------------------------------------------------------------


def test_limit_basic():
    records = [{"i": i} for i in range(10)]
    assert limit(records, 3) == [{"i": 0}, {"i": 1}, {"i": 2}]


def test_limit_zero():
    assert limit([{"a": 1}], 0) == []


def test_limit_larger_than_input():
    records = [{"a": 1}]
    assert limit(records, 100) == records


def test_limit_negative_raises():
    with pytest.raises(ValueError):
        limit([], -1)


def test_offset_basic():
    records = [{"i": i} for i in range(5)]
    assert offset(records, 2) == [{"i": 2}, {"i": 3}, {"i": 4}]


def test_offset_zero():
    records = [{"a": 1}]
    assert offset(records, 0) == records


def test_offset_negative_raises():
    with pytest.raises(ValueError):
        offset([], -1)


# ---------------------------------------------------------------------------
# group_by — single key (no collision risk)
# ---------------------------------------------------------------------------


def test_group_by_single_key():
    records = [
        {"cat": "A", "v": 1},
        {"cat": "B", "v": 2},
        {"cat": "A", "v": 3},
    ]
    groups = group_by(records, ["cat"])
    assert set(groups.keys()) == {"A", "B"}
    assert len(groups["A"]) == 2
    assert len(groups["B"]) == 1


def test_group_by_empty_input():
    assert group_by([], ["cat"]) == {}


def test_group_by_no_keys_raises():
    with pytest.raises(ValueError):
        group_by([{"a": 1}], [])


def test_group_by_missing_field_uses_empty_string():
    records = [{"a": 1}, {"b": 2}]
    groups = group_by(records, ["a"])
    assert "1" in groups
    assert "" in groups


# ---------------------------------------------------------------------------
# aggregate
# ---------------------------------------------------------------------------


def test_aggregate_count():
    records = [{"cat": "A", "v": 10}, {"cat": "A", "v": 20}]
    groups = group_by(records, ["cat"])
    result = aggregate(groups, "v", "count")
    assert result[0]["count"] == 2


def test_aggregate_sum():
    records = [{"cat": "A", "v": 10}, {"cat": "A", "v": 20}]
    groups = group_by(records, ["cat"])
    result = aggregate(groups, "v", "sum")
    assert result[0]["sum"] == 30.0


def test_aggregate_avg():
    records = [{"cat": "A", "v": 10}, {"cat": "A", "v": 30}]
    groups = group_by(records, ["cat"])
    result = aggregate(groups, "v", "avg")
    assert result[0]["avg"] == 20.0


def test_aggregate_min_max():
    records = [
        {"cat": "A", "v": 5},
        {"cat": "A", "v": 15},
        {"cat": "A", "v": 10},
    ]
    groups = group_by(records, ["cat"])
    assert aggregate(groups, "v", "min")[0]["min"] == 5.0
    assert aggregate(groups, "v", "max")[0]["max"] == 15.0


def test_aggregate_unknown_op_raises():
    groups = {"A": [{"v": 1}]}
    with pytest.raises(ValueError):
        aggregate(groups, "v", "median")


def test_aggregate_skips_none_values_for_numeric_ops():
    records = [{"cat": "A", "v": 10}, {"cat": "A", "v": None}]
    groups = group_by(records, ["cat"])
    result = aggregate(groups, "v", "sum")
    assert result[0]["sum"] == 10.0


def test_aggregate_count_includes_none_records():
    records = [
        {"cat": "A", "v": 10},
        {"cat": "A", "v": None},
        {"cat": "A", "v": 5},
    ]
    groups = group_by(records, ["cat"])
    result = aggregate(groups, "v", "count")
    assert result[0]["count"] == 3
