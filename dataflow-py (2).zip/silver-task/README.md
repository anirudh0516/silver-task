# Silver Task — dataflow-py group_by bug

## How to submit

### Step 1 — Upload the repository
Upload `dataflow-py.zip` on the Silver **Repositories** page.
The zip includes `.git/` with full commit history.

Wait for admin approval. Once approved, Silver shows the
**approved repo image reference** on the Repositories page.

### Step 2 — Fix the one placeholder
Open `environment/Dockerfile` and replace `REPO_IMAGE_PLACEHOLDER`
with the exact approved image reference from Step 1.



### Step 3 — Import and submit
On the Silver **Create tasks** page, click **Import**, upload
`silver-task.zip`, and hit **Submit**.

---

## Task summary

- **Bug location:** `dataflow/transforms.py` — `group_by()` function
- **Base commit:** `6373f2e0ddc7ebf9d818f2d0d970aa2632039998`
- **Difficulty:** medium
- **Category:** bug_fix
- **Author:** Anirudh Sharma <anirudh7120@gmail.com>
