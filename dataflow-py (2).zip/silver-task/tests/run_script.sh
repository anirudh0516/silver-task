#!/usr/bin/env bash
set -euo pipefail

cd /app

pytest tests/test_groupby_multikey.py tests/test_transforms.py tests/test_pipeline.py \
    -v --tb=short
