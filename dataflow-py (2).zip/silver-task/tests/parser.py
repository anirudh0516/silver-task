"""Parse pytest -v output into a list of {name, status} records."""

import json
import re
import sys


def parse_pytest(output: str) -> list:
    results = []
    # Match lines like: tests/foo.py::test_name PASSED  or  FAILED
    pattern = re.compile(
        r"^(tests/[\w/]+\.py::[\w\[\]_-]+)\s+(PASSED|FAILED|ERROR|SKIPPED)",
        re.MULTILINE,
    )
    for match in pattern.finditer(output):
        name, status = match.group(1), match.group(2)
        results.append({"name": name, "status": status.lower()})
    return results


if __name__ == "__main__":
    raw = sys.stdin.read()
    parsed = parse_pytest(raw)
    print(json.dumps(parsed))
