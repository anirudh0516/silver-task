"""
Silver task test: multi-key group_by with pipe characters in field values.

These tests verify that group_by produces a distinct group for each unique
combination of key values, even when the values themselves contain the
character used to construct composite keys internally.
"""

import pytest
from dataflow.transforms import group_by, aggregate


def test_group_by_multikey_distinct_groups():
    """Records with different key combinations must not be merged into one group."""
    records = [
        {"source": "api|v1", "env": "prod"},
        {"source": "api", "env": "v1|prod"},
        {"source": "batch", "env": "ok"},
    ]
    groups = group_by(records, ["source", "env"])
    assert len(groups) == 3, (
        f"Expected 3 distinct groups, got {len(groups)}. "
        f"Possible separator collision between ('api|v1','prod') "
        f"and ('api','v1|prod')."
    )


def test_group_by_multikey_aggregate_sums():
    """Aggregate sums must reflect each group's records independently."""
    records = [
        {"region": "us|east", "tier": "premium", "revenue": 100},
        {"region": "us", "tier": "east|premium", "revenue": 200},
        {"region": "us|east", "tier": "premium", "revenue": 150},
    ]
    groups = group_by(records, ["region", "tier"])
    result = aggregate(groups, "revenue", "sum")

    assert len(result) == 2, (
        f"Expected 2 groups after grouping by ['region', 'tier'], got {len(result)}"
    )
    sums = sorted(r["sum"] for r in result)
    assert sums == [200.0, 250.0], (
        f"Expected sums [200.0, 250.0], got {sums}. "
        f"If the two groups collide, the sum will be 450.0 for a single group."
    )
