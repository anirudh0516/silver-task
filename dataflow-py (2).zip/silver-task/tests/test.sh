#!/usr/bin/env bash
set -euo pipefail

LOGS=/logs/verifier
mkdir -p "$LOGS"

cd /app

# Extract and apply test_patch from config.json
PATCH=$(python3 -c "
import json, sys
with open('/task/tests/config.json') as f:
    d = json.load(f)
patch = d.get('test_patch', '')
sys.stdout.write(patch)
")
if [ -n "$PATCH" ]; then
    echo "$PATCH" | git apply -
fi

# Run the test suite, capture output
bash /task/tests/run_script.sh 2>&1 | tee "$LOGS/runner.log" || true

# Parse output to JSON
python3 /task/tests/parser.py < "$LOGS/runner.log" > "$LOGS/parsed.json"

# Evaluate required tests
python3 - << 'PYEOF'
import json, sys

with open('/logs/verifier/parsed.json') as f:
    results = json.load(f)

with open('/task/tests/config.json') as f:
    cfg = json.load(f)

status_map = {r['name']: r['status'] for r in results}

reward = 1
all_required = cfg.get('fail_to_pass', []) + cfg.get('pass_to_pass', [])

for name in all_required:
    status = status_map.get(name, 'missing')
    if status != 'passed':
        print(f'FAIL: {name} -> {status}', flush=True)
        reward = 0

with open('/logs/verifier/reward.txt', 'w') as f:
    f.write(str(reward))

print(f'Reward: {reward}', flush=True)
PYEOF
