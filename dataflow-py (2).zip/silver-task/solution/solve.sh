#!/usr/bin/env bash
set -euo pipefail

git apply << 'PATCH'
--- a/dataflow/transforms.py
+++ b/dataflow/transforms.py
@@ -137,9 +137,9 @@
     groups: Dict[str, List[Dict]] = {}
     for record in records:
         # Build a composite string key from the values of each grouping field.
-        # The pipe character "|" is used as a separator between field values.
-        group_key = "|".join(str(record.get(k, "")) for k in keys)
+        # A null byte separator prevents field-value collisions.
+        group_key = "\x00".join(str(record.get(k, "")) for k in keys)
         if group_key not in groups:
             groups[group_key] = []
         groups[group_key].append(record)
PATCH
