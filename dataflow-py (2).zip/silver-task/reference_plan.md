# Reference plan: group_by separator collision

## Root cause

`group_by` builds a composite string key by joining the values of each grouping
field with the pipe character `"|"`:

```python
group_key = "|".join(str(record.get(k, "")) for k in keys)
```

When a field value itself contains `"|"`, the resulting string is ambiguous.
For example:

| source   | env      | joined key    |
|----------|----------|---------------|
| `api|v1` | `prod`   | `api|v1|prod` |
| `api`    | `v1|prod`| `api|v1|prod` |

Both combinations produce the same `group_key`, so the records are merged into
one group instead of two.

## Intended fix

Replace the pipe separator with a character (or byte sequence) that cannot
appear in normal field values. The null byte `"\x00"` satisfies this because:

- JSON and CSV parsers never produce null bytes in string fields.
- Python strings can contain `"\x00"`, so no encoding changes are needed.

**One-line fix in `group_by`:**

```python
group_key = "\x00".join(str(record.get(k, "")) for k in keys)
```

This is backward-compatible: for a single key `["cat"]`, `"\x00".join(["A"])` is
just `"A"` — identical to the existing behaviour.

## What the tests cover

`test_group_by_multikey_distinct_groups` — verifies that three records with
distinct key combinations produce exactly three groups.

`test_group_by_multikey_aggregate_sums` — verifies that aggregated sums match
per-group values and are not merged into a single inflated total.

Both tests fail at `base_commit` because the pipe-joined key causes a collision
for the first two groups. Both pass after the null-byte fix is applied.

## Why this is a fair, hard task

The function works correctly for the common case (single key, or multi-key with
clean values) and the bug only surfaces with specific field values. The error
message from a failing assertion (`Expected 3 groups, got 2`) does not name the
root cause; the agent must trace the grouping logic to discover the separator
collision. The fix is a single character change but requires understanding why
the separator choice matters.
