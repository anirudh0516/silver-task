# Bug: group_by produces wrong groups when field values contain `|`

## Description

The `group_by` function in `dataflow/transforms.py` accepts a list of records
and a list of field names, and returns a dict mapping group identifiers to the
records that belong to each group.

When grouping by **multiple keys**, the function collapses records with different
key combinations into the same group if the field values happen to form the same
composite string — even when the actual key combinations are distinct.

## Example

```python
from dataflow.transforms import group_by, aggregate

records = [
    {"source": "api|v1", "env": "prod"},
    {"source": "api",    "env": "v1|prod"},
    {"source": "batch",  "env": "ok"},
]

groups = group_by(records, ["source", "env"])
print(len(groups))  # prints 2 — should be 3
```

The first two records have completely different `source`/`env` values but end
up in the same group, which causes downstream aggregations (sum, count, avg,
etc.) to produce incorrect results.

## Expected behaviour

`group_by(records, ["source", "env"])` must return **one group per unique
combination of key values**. The example above should produce 3 separate groups.
Aggregating revenue by `["region", "tier"]` over:

```python
[
    {"region": "us|east", "tier": "premium", "revenue": 100},
    {"region": "us",      "tier": "east|premium", "revenue": 200},
    {"region": "us|east", "tier": "premium", "revenue": 150},
]
```

should yield two groups with sums of **250.0** and **200.0** respectively —
not a single group with a sum of **450.0**.

## Constraints

- Only `dataflow/transforms.py` needs to change.
- The fix must not break single-key grouping or any existing aggregation behaviour.
- Do not change the function signature.
